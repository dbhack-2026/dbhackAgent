from typing import Any
from urllib.parse import urlparse
import requests
import google.auth.transport.requests
import google.oauth2.id_token
from app.config import get_settings

settings = get_settings()
auth_request = google.auth.transport.requests.Request()

def audience(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.netloc:
        raise ValueError("Endpoint URL must be absolute HTTPS")
    return f"{parsed.scheme}://{parsed.netloc}"

def get_json(base_url: str, path: str, params: dict[str, Any]) -> dict[str, Any]:
    headers = {"Accept": "application/json"}
    if settings.endpoints_are_private_cloud_run:
        token = google.oauth2.id_token.fetch_id_token(auth_request, audience(base_url))
        headers["Authorization"] = f"Bearer {token}"
    elif settings.endpoint_api_key:
        headers["X-API-Key"] = settings.endpoint_api_key
    response = requests.get(
        f"{base_url.rstrip('/')}/{path.lstrip('/')}",
        params={k: v for k, v in params.items() if v not in (None, "")},
        headers=headers,
        timeout=settings.request_timeout_seconds,
    )
    response.raise_for_status()
    body = response.json()
    return body if isinstance(body, dict) else {"data": body}
