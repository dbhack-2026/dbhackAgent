from app.config import get_settings
from app.http_client import get_json

settings = get_settings()

TOOLS = [
    {
        "type": "function",
        "name": "get_trade_by_source_trade_id",
        "description": "Fetch trade data for an exact source trade ID. Use for trade, execution, settlement, price, quantity, counterparty, or trade-status questions.",
        "parameters": {
            "type": "object",
            "properties": {"source_trade_id": {"type": "string", "description": "Exact source trade ID supplied by the user."}},
            "required": ["source_trade_id"],
            "additionalProperties": False,
        },
        "strict": True,
    },
    {
        "type": "function",
        "name": "get_position_by_source_position_id",
        "description": "Fetch position data for an exact source position ID. Use for holdings, exposure, market value, P&L, position quantity, or position questions.",
        "parameters": {
            "type": "object",
            "properties": {"source_position_id": {"type": "string", "description": "Exact source position ID supplied by the user."}},
            "required": ["source_position_id"],
            "additionalProperties": False,
        },
        "strict": True,
    },
]

def get_trade_by_source_trade_id(source_trade_id: str):
    try:
        return {"status": "success", "tool": "trade", "source_trade_id": source_trade_id, "result": get_json(settings.trade_service_url, f"/api/trades/{source_trade_id}", {})}
    except Exception as exc:
        return {"status": "error", "tool": "trade", "source_trade_id": source_trade_id, "message": f"Trade endpoint failed: {type(exc).__name__}"}

def get_position_by_source_position_id(source_position_id: str):
    try:
        return {"status": "success", "tool": "position", "source_position_id": source_position_id, "result": get_json(settings.position_service_url, f"/api/positions/{source_position_id}", {})}
    except Exception as exc:
        return {"status": "error", "tool": "position", "source_position_id": source_position_id, "message": f"Position endpoint failed: {type(exc).__name__}"}

FUNCTIONS = {
    "get_trade_by_source_trade_id": get_trade_by_source_trade_id,
    "get_position_by_source_position_id": get_position_by_source_position_id,
}
