from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    openai_api_key: str
    openai_model: str = "gpt-5.4-mini"
    trade_service_url: str
    position_service_url: str
    endpoints_are_private_cloud_run: bool = True
    endpoint_api_key: str | None = None
    request_timeout_seconds: int = 20
    max_tool_rounds: int = 4
    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False, extra="ignore")

@lru_cache
def get_settings() -> Settings:
    return Settings()
