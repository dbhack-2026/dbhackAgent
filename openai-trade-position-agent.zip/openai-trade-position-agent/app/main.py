from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from app.agent import run_agent

app = FastAPI(title="OpenAI Trade Position Agent", version="1.0.0")

class AskRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=8000)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/ask")
def ask(request: AskRequest):
    try:
        return run_agent(request.prompt)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Agent execution failed: {type(exc).__name__}") from exc
