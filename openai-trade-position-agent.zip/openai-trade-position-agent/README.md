# OpenAI Trade and Position Agent on GCP Cloud Run

Python FastAPI agent using the OpenAI Responses API with two function tools. It infers whether a prompt contains a source trade ID or source position ID, calls the matching endpoint, and analyzes the returned JSON.

## Expected endpoints

```http
GET {TRADE_SERVICE_URL}/api/trades/{source_trade_id}
GET {POSITION_SERVICE_URL}/api/positions/{source_position_id}
```

Change the paths in `app/tools.py` if needed.

## Local run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8080
```

## Deploy to GCP

```bash
export PROJECT_ID='your-project-id'
export REGION='asia-south1'
export AGENT_SERVICE='openai-trade-position-agent'
export AGENT_SA="openai-trade-position-agent@$PROJECT_ID.iam.gserviceaccount.com"
export TRADE_SERVICE_URL='https://your-trade-service.run.app'
export POSITION_SERVICE_URL='https://your-position-service.run.app'

gcloud config set project "$PROJECT_ID"
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com secretmanager.googleapis.com iam.googleapis.com
gcloud iam service-accounts create openai-trade-position-agent --display-name='OpenAI Trade Position Agent'
```

For private Cloud Run data APIs, grant this service account `roles/run.invoker` on each service.

Create the OpenAI key secret:

```bash
gcloud secrets create openai-api-key --replication-policy=automatic
read -s OPENAI_KEY
printf '%s' "$OPENAI_KEY" | gcloud secrets versions add openai-api-key --data-file=-
unset OPENAI_KEY
gcloud secrets add-iam-policy-binding openai-api-key --member="serviceAccount:$AGENT_SA" --role='roles/secretmanager.secretAccessor'
```

Deploy:

```bash
gcloud run deploy "$AGENT_SERVICE" \
  --source=. \
  --region="$REGION" \
  --service-account="$AGENT_SA" \
  --no-allow-unauthenticated \
  --set-secrets='OPENAI_API_KEY=openai-api-key:latest' \
  --set-env-vars="OPENAI_MODEL=gpt-5.4-mini,TRADE_SERVICE_URL=$TRADE_SERVICE_URL,POSITION_SERVICE_URL=$POSITION_SERVICE_URL,ENDPOINTS_ARE_PRIVATE_CLOUD_RUN=true,REQUEST_TIMEOUT_SECONDS=20,MAX_TOOL_ROUNDS=4" \
  --memory=1Gi --cpu=1 --min=0 --max=3 --timeout=300
```

Test:

```bash
export AGENT_URL="$(gcloud run services describe "$AGENT_SERVICE" --region="$REGION" --format='value(status.url)')"
curl -X POST "$AGENT_URL/ask" \
  -H "Authorization: Bearer $(gcloud auth print-identity-token)" \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"For source position ID POS-9001, what is the current market value and P&L?"}'
```
