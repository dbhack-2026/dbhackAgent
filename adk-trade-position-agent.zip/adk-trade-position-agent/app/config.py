from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    google_cloud_project: str
    google_cloud_location: str = "global"
    google_genai_use_vertexai: bool = True
    agent_model: str = "gemini-2.5-flash"
    trade_service_url: str
    position_service_url: str
    request_timeout_seconds: int = 20
    max_tool_rows: int = 100

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False, extra="ignore")

@lru_cache
def get_settings() -> Settings:
    return Settings()
