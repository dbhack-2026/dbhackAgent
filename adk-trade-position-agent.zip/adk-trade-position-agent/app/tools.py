from typing import Any
from app.cloud_run_client import CloudRunClient
from app.config import get_settings

settings = get_settings()
client = CloudRunClient(settings.request_timeout_seconds)

def get_trade_data(
    trade_id: str = "",
    account_id: str = "",
    product_id: str = "",
    trade_date: str = "",
    limit: int = 25,
) -> dict[str, Any]:
    """Retrieve approved trade data.

    Use for questions about trades, trade status, executions, prices,
    quantities, counterparties, products, or trade dates.

    Args:
        trade_id: Exact trade identifier.
        account_id: Account or portfolio identifier.
        product_id: Product or instrument identifier.
        trade_date: Date in YYYY-MM-DD.
        limit: Maximum rows, from 1 to 100.
    """
    if not any([trade_id, account_id, product_id, trade_date]):
        return {"status": "error", "error_message": "At least one trade filter is required."}
    try:
        return client.get(settings.trade_service_url, "/api/trades", {
            "tradeId": trade_id,
            "accountId": account_id,
            "productId": product_id,
            "tradeDate": trade_date,
            "limit": max(1, min(limit, settings.max_tool_rows)),
        })
    except Exception as exc:
        return {"status": "error", "error_message": f"Trade API failed: {type(exc).__name__}"}

def get_position_data(
    account_id: str = "",
    product_id: str = "",
    as_of_date: str = "",
    limit: int = 25,
) -> dict[str, Any]:
    """Retrieve approved position data.

    Use for questions about holdings, positions, exposure, market value,
    P&L, quantities, account positions, or as-of dates.

    Args:
        account_id: Account or portfolio identifier.
        product_id: Product or instrument identifier.
        as_of_date: Date in YYYY-MM-DD.
        limit: Maximum rows, from 1 to 100.
    """
    if not any([account_id, product_id, as_of_date]):
        return {"status": "error", "error_message": "At least one position filter is required."}
    try:
        return client.get(settings.position_service_url, "/api/positions", {
            "accountId": account_id,
            "productId": product_id,
            "asOfDate": as_of_date,
            "limit": max(1, min(limit, settings.max_tool_rows)),
        })
    except Exception as exc:
        return {"status": "error", "error_message": f"Position API failed: {type(exc).__name__}"}
