import uuid
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from app.agent import root_agent

APP_NAME = "trade-position-agent"
app = FastAPI(title="ADK Trade and Position Agent", version="1.0.0")
sessions = InMemorySessionService()
runner = Runner(agent=root_agent, app_name=APP_NAME, session_service=sessions)

class PromptRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=8000)
    user_id: str = Field(default="api-user", min_length=1, max_length=200)
    session_id: str | None = Field(default=None, max_length=200)

class PromptResponse(BaseModel):
    session_id: str
    response: str

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/prompt", response_model=PromptResponse)
async def prompt(request: PromptRequest):
    session_id = request.session_id or str(uuid.uuid4())
    existing = await sessions.get_session(
        app_name=APP_NAME, user_id=request.user_id, session_id=session_id
    )
    if existing is None:
        await sessions.create_session(
            app_name=APP_NAME, user_id=request.user_id, session_id=session_id
        )

    message = types.Content(
        role="user",
        parts=[types.Part(text=request.prompt)],
    )

    final_text = ""
    try:
        async for event in runner.run_async(
            user_id=request.user_id,
            session_id=session_id,
            new_message=message,
        ):
            if event.is_final_response() and event.content and event.content.parts:
                final_text = "".join(
                    p.text or "" for p in event.content.parts if getattr(p, "text", None)
                )
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Agent execution failed: {type(exc).__name__}",
        ) from exc

    if not final_text:
        raise HTTPException(status_code=502, detail="Agent returned no final response")

    return PromptResponse(session_id=session_id, response=final_text)
