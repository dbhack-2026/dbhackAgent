from typing import Any
from urllib.parse import urlparse
import requests
import google.auth.transport.requests
import google.oauth2.id_token

class CloudRunClient:
    def __init__(self, timeout_seconds: int = 20):
        self.timeout_seconds = timeout_seconds
        self.auth_request = google.auth.transport.requests.Request()

    @staticmethod
    def audience(base_url: str) -> str:
        parsed = urlparse(base_url)
        if parsed.scheme != "https" or not parsed.netloc:
            raise ValueError("Cloud Run URL must be absolute HTTPS")
        return f"{parsed.scheme}://{parsed.netloc}"

    def get(self, base_url: str, path: str, params: dict[str, Any]) -> dict[str, Any]:
        token = google.oauth2.id_token.fetch_id_token(
            self.auth_request, self.audience(base_url)
        )
        response = requests.get(
            f"{base_url.rstrip('/')}/{path.lstrip('/')}",
            params={k: v for k, v in params.items() if v not in (None, "")},
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
            timeout=self.timeout_seconds,
        )
        response.raise_for_status()
        body = response.json()
        return body if isinstance(body, dict) else {"status": "success", "data": body}
